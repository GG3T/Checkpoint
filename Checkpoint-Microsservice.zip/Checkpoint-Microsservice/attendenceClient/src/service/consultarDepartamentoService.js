const axios = require('axios');

const URL = 'http://localhost:4002/departamento';

const consultarDepartamento = async (id) => {  // Adicionamos um parâmetro id aqui
    const requestUrl = id ? `${URL}/${id}` : URL;  // Se o id for fornecido, anexe-o à URL
    try {
        const response = await axios.get(requestUrl);
        return response.data;
    } catch (error) {
        console.error('Erro ao buscar os dados:', error);
        throw error;
    }
};

module.exports = consultarDepartamento;