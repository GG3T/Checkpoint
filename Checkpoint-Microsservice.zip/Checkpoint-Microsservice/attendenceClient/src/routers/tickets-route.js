const express = require('express')
const router = express.Router();

//vamos expor os metodos que criamos na nossa controller
const controller = require('../controllers/ticket-controller');

router.get('/', controller.get) //expondo metodo getAll, com sua rota
router.post('/', controller.post)
router.get('/:id', controller.getById);

module.exports = router; //para podermos exportar essas rotas

