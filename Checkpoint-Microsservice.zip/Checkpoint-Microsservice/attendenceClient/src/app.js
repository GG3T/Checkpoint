//app.js arquivo de config do nosso HTTP
const express = require('express') //import dos pacotes do express para o folder node_modules?
const app = express() //criar instancia do express
app.use(express.json())
const mongoose = require('mongoose')

mongoose.connect('mongodb://fiap:123456@localhost:27017/admin')

app.use(express.urlencoded({
    extended: true
}))

//REGISTRO DA MODEL (Serve para podermos usa-la no repository e na controller (dentro das rotas))
//temos que fazer isso sempre que precisamos usar um objeto dentro do outro
require('./models/attendence')

//require das ROTAS
const atendenteRouter = require('./routers/atendente-route')
const ticketsRouter = require('./routers/tickets-route')
const registroRouter = require('./routers/registro-route')


app.use('/atendente', atendenteRouter) 
app.use('/tickets', ticketsRouter) 
app.use('/registro', registroRouter) 

module.exports = app; //exportando o app com o module