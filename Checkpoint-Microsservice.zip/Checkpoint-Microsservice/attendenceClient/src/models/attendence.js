const mongoose = require('mongoose') //biblioteca que estamos usando
const Schema = mongoose.Schema; //objeto do mongoose para modelarmos o objeto no banco de dados que iremos usar

//Colunas que serão parte do MySQL, modelo do Schema:

const atendenteSchema = new Schema({
    id: {
        type: Number,
        required: true
    },
    pessoa: {
        type: String,
        required: true
    },
    identificadorDoSetor: {
        type: String,
        required: false
    }
});

const registroSchema = new Schema({
    id: {
        type: Number,
        required: true
    },
    texto: {
        type: String,
        required: true
    },
    ticket: {
        type: Number,
        ref: 'Ticket',
        required: true
    }
});

const ticketSchema = new Schema({
    id: {
        type: Number,
        required: true
    },
    atendente: {
        type: Schema.Types.ObjectId, // Referenciando o ID do Atendente
        ref: 'Atendente',
        required: true
    },
    titulo: {
        type: String,
        required: true
    },
    telefone: {
        type: String,
        required: true
    },
    identificador: {
        type: String,
        required: true
    },
    cliente: {
        type: String,
        required: true
    }
});

module.exports = {
    Atendente: mongoose.model('Atendente', atendenteSchema),
    Ticket: mongoose.model('Ticket', ticketSchema),
    Registro: mongoose.model('Registro', registroSchema)
};