let errors = [] //com isso podemos mandar uma LISTA de erros

function ValidationContract() {
    errors = [] //zeramos array toda hora q chamarmos essa funcao
}

ValidationContract.prototype.isRequired = (value, message) =>{ //prototype serve para criar e instanciar funcao 5:50 aula 36
    if(!value || value.length <= 0)
        errors.push({message : message}) //deixamos mensagens de erro padronizadas aula 36
}

ValidationContract.prototype.hasMinLen = (value, min, message) =>{ // 7:00 aula 36 quando precisamos de um MINIMO de caracteres para algum post de dados
    if(!value || value.length < min)
        errors.push({message : message}) 
}

ValidationContract.prototype.hasMinLen = (value, max, message) =>{ //sao mais validacoes de regra de negocio
    if(!value || value.length > max)
        errors.push({message : message}) 
}

ValidationContract.prototype.isValid = () =>{


    return errors.length == 0; //0 significa OK, deu certo, nao tem erro na lista 24:50 aula 36
}

module.exports = ValidationContract //para permitir exportacao do js validator