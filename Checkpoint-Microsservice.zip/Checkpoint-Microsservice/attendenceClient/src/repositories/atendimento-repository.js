const mongoose = require('mongoose')
const Atendente = mongoose.model('Atendente') //exatamente o nome dado no export da modelo do produto!!!

//exports servem para que quando colocarmos nosso repositorio no app, será nativo ao HTTP ***** 46:20 33

exports.get = async()=>{ //get para pegar todas colecoes ativas (tabelas)
    const result = await Atendente.find() //espere o servidor do banco responder
    return result;
}

exports.getById = async(id) => {
    const result = await Atendente.findOne({ id: id });  // Nota: Estamos usando findOne com { id: id }
    console.log(result);
    return result;
};

exports.create = async(data) => {
    let atendente = new Atendente(data);
    console.log(data)
    try {
        await atendente.save();
    } catch (error) {
        console.error("Erro ao salvar o atendente:", error);
    }
}
exports.deleteAll = async () => {
    try {
        return await Atendente.deleteMany({});
    } catch (error) {
        throw error;
    }
};