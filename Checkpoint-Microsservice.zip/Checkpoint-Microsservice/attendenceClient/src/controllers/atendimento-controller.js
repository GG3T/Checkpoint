const { response } = require("express")
const repository = require("../repositories/atendimento-repository") //puxamos o repositorio
const consultarDepartamento = require('../service/consultarDepartamentoService');
const ValidationContract = require('../util/validator') //INSTANCIANDO as funcoes de validacao aula 36

//role = "manager" (autentificacao para fazer o "getAll")
exports.get = async(req, res, next) =>{ //GET
    const data = await repository.get();
    console.log(data)

    if(data == null) //validacao aula 36 13:00
        res.status(204).send(); //não devolve nada, apesar de ter funcionado, not found
    
  res.status(200).send(data); //response   
};

exports.getById = async (req, res) => {
    try {
        const id = req.params.id;
        const departamento = await consultarDepartamento(id);
        const data = await repository.getById(id);
        if (data) {
           
            res.status(200).send(data); 
        } else {
            res.status(404).send({
                message: 'folha não encontrada para o ID fornecido'
            });
        }
    } catch (e) {
        console.log(e)
        res.status(500).send({
            message: 'Falha ao processar sua requisição',
            error: e
        });
    }
};

exports.post = async(req, res, next) => {
    let contract = new ValidationContract();

    try {

        if (!contract.isRequired) { 
            return res.status(400).send({ message: "Erro ao cadastrar as informações. Favor validar" });
        }

        const identificadorDoSetor = req.body.identificadorDoSetor;
        console.log(identificadorDoSetor)

        const departamento = await consultarDepartamento(identificadorDoSetor);
        if (!departamento) {
            return res.status(204).send({ message: "Departamento não encontrado" });
        }

        const newAtendente = {
            id: req.body.id,
            pessoa: req.body.pessoa,
            identificadorDoSetor: departamento.departamento.setor
        };
    
        await repository.create(newAtendente);
        return res.status(201).send("Criado com sucesso!");
    } catch (error) {
        console.error("Erro ao criar o registro:", error);
        return res.status(500).send({ message: "Erro no servidor, favor contactar o administrador." });
    }
};



