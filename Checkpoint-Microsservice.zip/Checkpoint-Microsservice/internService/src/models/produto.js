const mongoose = require('mongoose') //biblioteca que estamos usando
const Schema = mongoose.Schema; //objeto do mongoose para modelarmos o objeto no banco de dados que iremos usar

const DepartamentoSchema = new Schema({
    id: {
        type: Number,
        required: true,
    },
    codigo: {
        type: Number,
        required: true,
    },
    nome: {
        type: String,
        required: true
    },
    setor: {
        type: String,
        required: true
    }
});

const PessoaSchema = new Schema({
    id: {
        type: Number,
        required: true,
    },
    nome: {
        type: String,
        required: true
    },
    documento: {
        type: String,
        required: true,
        unique: true // Assumindo que cada pessoa deve ter um documento único
    },
    endereco: {
        type: String,
        required: true
    },
    telefone: {
        type: String,
        required: true
    }
});

module.exports = {
    Departamento: mongoose.model('Departamento', DepartamentoSchema),
    Pessoa: mongoose.model('Pessoa', PessoaSchema),
};