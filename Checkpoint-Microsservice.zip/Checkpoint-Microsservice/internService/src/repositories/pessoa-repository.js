const mongoose = require('mongoose')
const Pessoa = mongoose.model('Pessoa') //exatamente o nome dado no export da modelo do produto!!!

//exports servem para que quando colocarmos nosso repositorio no app, será nativo ao HTTP ***** 46:20 33

exports.get = async()=>{ //get para pegar todas colecoes ativas (tabelas)
    const result = await Pessoa.find() //espere o servidor do banco responder
    return result;
}

exports.getById = async(id) => {
    const result = await Pessoa.findOne({ id: id });  // Nota: Estamos usando findOne com { id: id }
    console.log(result);
    return result;
};


exports.create = async(data) => {
    let pessoa = new Pessoa(data);
    console.log(data)
    try {
        await pessoa.save();
    } catch (error) {
        console.error("Erro ao salvar o pessoa:", error);
    }
}
