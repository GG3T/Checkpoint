//app.js arquivo de config do nosso HTTP
const express = require('express'); //import dos pacotes do express para o folder node_modules?
const app = express(); //criar instancia do express
app.set('port', 4002); //alterar a porta para 4002
app.use(express.json())
const mongoose = require('mongoose')

mongoose.connect('mongodb://fiap:123456@localhost:27017/admin')

app.use(express.urlencoded({
    extended: true
}))

//REGISTRO DA MODEL (Serve para podermos usa-la no repository e na controller (dentro das rotas))
//temos que fazer isso sempre que precisamos usar um objeto dentro do outro
require('./models/produto')

//require das ROTAS
const departmentRouter = require('./routers/department-route')
const peopleRouter = require('./routers/pessoa-route')



app.use('/departamento', departmentRouter) 
app.use('/pessoa', peopleRouter) 

module.exports = app; //exportando o app com o module