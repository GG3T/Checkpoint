const mongoose = require('mongoose') //biblioteca que estamos usando
const Schema = mongoose.Schema; //objeto do mongoose para modelarmos o objeto no banco de dados que iremos usar

const folhaSchema = new Schema({
    id: {
        type: String,
        ref: 'Pessoa',
        required: true
    },
    codigoPessoa: {
        type: String,
        ref: 'Pessoa',
        required: true
    },
    salario: {
        type: Number,
        required: true
    },
    data: {
        type: Date,
        default: Date.now,
        required: true
    },
    codigo: {
        type: Number,
        required: true,
    },
    departamento: {
        type: String,
        ref: 'Departamento',
        required: true
    }
});

module.exports = mongoose.model('Folha', folhaSchema);