const mongoose = require('mongoose')
const Folha = mongoose.model('Folha') //exatamente o nome dado no export da modelo do produto!!!

//exports servem para que quando colocarmos nosso repositorio no app, será nativo ao HTTP ***** 46:20 33

exports.get = async()=>{ //get para pegar todas colecoes ativas (tabelas)
    const result = await Folha.find() //espere o servidor do banco responder
    return result;
}

exports.getById = async(id) => {
    const result = await Folha.findOne({ id: id });  // Nota: Estamos usando findOne com { id: id }
    console.log(result);
    return result;
};
exports.create = async(data) => {
    let folha = new Folha(data);
    console.log(data)
    try {
        await folha.save();
    } catch (error) {
        console.error("Erro ao salvar o folha:", error);
    }
}
