const { response } = require("express")
const repository = require("../repositories/folha-repository") //puxamos o repositorio
const ValidationContract = require('../util/validator') //INSTANCIANDO as funcoes de validacao aula 36
const consultarPessoa = require('../service/consultarPessoasService');
//role = "manager" (autentificacao para fazer o "getAll")
exports.get = async(req, res, next) =>{ //GET
    const data = await repository.get();

    if(data == null) //validacao aula 36 13:00
        res.status(204).send(); //não devolve nada, apesar de ter funcionado, not found
    
  res.status(200).send(data); //response   
};


exports.getById = async (req, res) => {
    try {
        const id = req.params.id;
        const folha = await repository.getById(id);
        const pessoas = await consultarPessoa(id);
        if (folha) {
            const combinedData = {
                folha: folha,
                pessoa: pessoas
            };
            res.status(200).send(combinedData); 
        } else {
            res.status(204).send({
                message: 'folha não encontrada para o ID fornecido'
            });
        }
    } catch (e) {
        console.log(e)
        res.status(500).send({
            message: 'Falha ao processar sua requisição',
            error: e
        });
    }
};

//role = "manager, attendant" (se alguem com autentificacao mas sem permissao tentar acessar, da 403 Forbidden)
exports.post = async(req, res, next) =>{ //POST
    let contract = new ValidationContract();//validacao do post 17:30 aula 36
    try {

        try {
            const pessoas = await consultarPessoa(); // Supondo que retornará um array de pessoas
            
            if(pessoas && pessoas == null) {
                console.log(pessoas.id)
                req.body.codigoPessoa = pessoas._id; 
            }
    
        } catch(error) {
            console.error("Erro ao consultar pessoa:", error);
            res.status(204).send({ message: "Erro ao consultar os dados da pessoa." });
            return; 
        }

        if(!contract.isRequired){ 
            res.status(400).send({message: "Erro ao cadastrar as informações. Favor validar"});
            return;
        }
          
        await repository.create(req.body) //pegamos a requisicao do body (o usuario manda) e criamos no BD
        res.status(201).send("Criado com sucesso!") //mudamos de 200 para 201 (Created) aula 36
    } catch (error) { //erro 500 30:00 aula 36
        res.status(500).send({message: "Erro no servidor, favor contactar o administrador."})
    }
};