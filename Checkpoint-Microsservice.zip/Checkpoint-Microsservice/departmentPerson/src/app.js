//app.js arquivo de config do nosso HTTP
const express = require('express') //import dos pacotes do express para o folder node_modules?
const app = express() //criar instancia do express
app.use(express.json())
const mongoose = require('mongoose')

mongoose.connect('mongodb://fiap:123456@localhost:27017/admin')

app.use(express.urlencoded({
    extended: true
}))

//REGISTRO DA MODEL (Serve para podermos usa-la no repository e na controller (dentro das rotas))
//temos que fazer isso sempre que precisamos usar um objeto dentro do outro
require('./models/folha')

//require das ROTAS
const folhaRouter = require('./routers/folha-route')


app.use('/folha', folhaRouter) 

module.exports = app; //exportando o app com o module